# Sony Cam (HXR-MC2500 WiFi)

Control the Sony HXR-MC2500 over WiFi using the Camera Remote API.

## Setup
1. Pi must be connected to the camera's WiFi (setup_wifi.sh does this, autoconnect saved).
2. Set the API endpoint in the connection config:
   http://192.168.122.1:10000/sony/camera
3. Zoom +/-. Hold for continuous, release to stop. AF buttons set focus points.

## Notes
- Record over WiFi is firmware-blocked on the MC2500 (error 40400) - REC buttons will error.
- The camera must be in remote-capable state; module switches it to movie mode at startup.
